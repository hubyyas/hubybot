import os
import openai
from telegram import Update
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackContext

# نجلب المفاتيح من البيئة
openai.api_key = os.getenv("OPENAI_API_KEY")
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")

# رد بدء البوت
def start(update: Update, context: CallbackContext):
    update.message.reply_text("هلا بيك! آني بوت هوبي 🤖، اسألني أي شي عن البرمجة وأنا أجاوبك.")

# التعامل مع الرسائل
def handle_message(update: Update, context: CallbackContext):
    user_text = update.message.text

    # إذا المستخدم غلط
    bad_words = ["غبي", "حمار", "تافه", "كسكول", "fuck", "كسمك"]
    if any(word in user_text.lower() for word in bad_words):
        update.message.reply_text("هااا حبيبي؟ لا تجبرني أفرمت جهازك وتره سهلة عليه 😎")
        return

    try:
        # إرسال السؤال للذكاء الاصطناعي
        response = openai.ChatCompletion.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "إنت بوت عراقي ودود، تجاوب باللهجة العراقية، وتحب البرمجة وتكتب أكواد بايثون."},
                {"role": "user", "content": user_text}
            ]
        )
        answer = response.choices[0].message.content
        update.message.reply_text(answer)

    except Exception as e:
        update.message.reply_text(f"صايرة مشكلة حبي، هاي تفاصيلها: {e}")

def main():
    updater = Updater(TELEGRAM_BOT_TOKEN, use_context=True)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, handle_message))

    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()